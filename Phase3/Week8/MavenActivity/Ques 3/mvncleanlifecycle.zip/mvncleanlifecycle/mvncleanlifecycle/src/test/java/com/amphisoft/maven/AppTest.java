package com.amphisoft.maven;

public class AppTest  {
	
    public void testApp() {
        
    }
    
}
